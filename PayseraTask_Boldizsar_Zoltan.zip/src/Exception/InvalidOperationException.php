<?php

namespace Paysera\CommissionTask\Exception;

class InvalidOperationException extends \Exception
{
}
