<?php

namespace Paysera\CommissionTask\Exception;

class InvalidCurrencyTypeException extends \Exception
{
}
