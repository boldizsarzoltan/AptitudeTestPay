<?php

namespace Paysera\CommissionTask\Exception;

class UnknownOperationException extends \Exception
{
}
