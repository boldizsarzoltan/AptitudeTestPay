<?php

namespace Paysera\CommissionTask\Exception;

class InvalidOperationTypeException extends \Exception
{
}
