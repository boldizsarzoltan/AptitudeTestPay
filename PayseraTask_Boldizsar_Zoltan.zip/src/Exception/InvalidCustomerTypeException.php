<?php

namespace Paysera\CommissionTask\Exception;

class InvalidCustomerTypeException extends \Exception
{
}
