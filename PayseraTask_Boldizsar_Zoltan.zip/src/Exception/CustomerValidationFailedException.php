<?php

namespace Paysera\CommissionTask\Exception;

class CustomerValidationFailedException extends \Exception
{
}
